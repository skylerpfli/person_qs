package com.sendtion.xrichtext;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * 用户生成GlideApp，沿用Glide3版本使用方式
 */
@GlideModule
public final class MyGlideModule extends AppGlideModule {
}
